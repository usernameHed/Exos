#ifndef VERTEX_H
#define VERTEX_H

#include "object.h"

extern Class * Vertex;

#endif
