#ifndef POINT_H
#define POINT_H

#include "object.h"

extern Class * Point;

#endif
