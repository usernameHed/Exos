
#ifndef BOOL_H
# define BOOL_H

typedef int bool;

#define false 0
#define true (!false)

#endif

