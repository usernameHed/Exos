
#ifndef FLOAT_H
# define FLOAT_H

# include "object.h"

extern Class* Float;

#endif

