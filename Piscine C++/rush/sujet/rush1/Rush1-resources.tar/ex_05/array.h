
#ifndef ARRAY_H
# define ARRAY_H

# include "container.h"

extern Class* Array; /* Array(size, Type, ...)  where ellipsis are Type constructor arguments */

#endif

